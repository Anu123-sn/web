const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MySQL Connection
const db = mysql.createConnection({
  host: "localhost",      // Your MySQL host (use 'localhost' if running locally)
  user: "root",           // Your MySQL username
  password: "ANU@123",           // Your MySQL password
  database: "feedbackDB"  // The database you created earlier
});

// Connect to MySQL
db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL:", err.stack);
    return;
  }
  console.log("Connected to MySQL");
});

// API Routes
// Submit feedback
app.post("/submit-feedback", (req, res) => {
  const { name, email, feedback_text } = req.body;

  const query = "INSERT INTO feedbacks (name, email, feedback_text) VALUES (?, ?, ?)";
  db.query(query, [name, email, feedback_text], (err, result) => {
    if (err) {
      console.error("Error inserting feedback:", err);
      return res.status(500).send("Error saving feedback");
    }
    res.send("Feedback submitted successfully!");
  });
});

// Get all feedback
app.get("/get-feedback", (req, res) => {
  const query = "SELECT * FROM feedbacks ORDER BY submitted_at DESC";
  db.query(query, (err, results) => {
    if (err) {
      console.error("Error retrieving feedback:", err);
      return res.status(500).send("Error retrieving feedback");
    }
    res.json(results);
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
