document.addEventListener("DOMContentLoaded", function() {
    const feedbackForm = document.getElementById("feedback-form");
    const feedbackText = document.getElementById("feedback");
    const feedbackList = document.getElementById("feedback-list");

    // Load existing feedback from localStorage
    loadFeedback();

    // Handle form submission
    feedbackForm.addEventListener("submit", function(event) {
        event.preventDefault();

        // Get the feedback from the textarea
        const feedback = feedbackText.value.trim();

        if (feedback !== "") {
            // Save feedback to localStorage
            saveFeedback(feedback);

            // Clear the textarea
            feedbackText.value = "";

            // Load the updated feedback list
            loadFeedback();
        }
    });

    // Function to save feedback to localStorage
    function saveFeedback(feedback) {
        let storedFeedback = JSON.parse(localStorage.getItem("feedbackData")) || [];
        storedFeedback.push(feedback);
        localStorage.setItem("feedbackData", JSON.stringify(storedFeedback));
    }

    // Function to load and display feedback
    function loadFeedback() {
        const storedFeedback = JSON.parse(localStorage.getItem("feedbackData")) || [];
        feedbackList.innerHTML = "";
        storedFeedback.forEach(function(feedback) {
            const feedbackItem = document.createElement("div");
            feedbackItem.classList.add("feedback-item");
            feedbackItem.textContent = feedback;
            feedbackList.appendChild(feedbackItem);
        });
    }
});

  