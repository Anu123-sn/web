function loginUser(event) {
    event.preventDefault();  // Prevents form submission to server

    // Get values from the input fields
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    // Display a simple message for logging in
    alert("Logged in successfully ! The login details are Username:  " + username + ", Password: " + password);
    window.location.assign("home.html")
}
